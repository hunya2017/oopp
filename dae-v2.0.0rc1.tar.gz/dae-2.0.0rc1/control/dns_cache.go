/*
 * SPDX-License-Identifier: AGPL-3.0-only
 * Copyright (c) 2022-2025, daeuniverse Organization <dae@v2raya.org>
 */

package control

import (
	"net/netip"
	"slices"
	"sync/atomic"
	"time"

	dnsmessage "github.com/miekg/dns"
)

// Approximate TTL refresh threshold in seconds.
// Pre-packed response is refreshed when TTL difference exceeds this value.
// This balances between performance (avoiding frequent repack) and TTL accuracy.
// NOTE: Increased from 5 to 15 to reduce memory allocation frequency under high load
// while maintaining acceptable TTL accuracy (15s variance is negligible for DNS caching).
const ttlRefreshThresholdSeconds = 15

// BPF update configuration
const (
	// MinBpfUpdateInterval is the minimum time between BPF map updates for the same cache.
	// This prevents excessive BPF map updates while maintaining freshness.
	MinBpfUpdateInterval = 1 * time.Second

	// MaxBpfUpdateInterval is the maximum time before forcing a BPF map update.
	// Even if data hasn't changed, we refresh periodically to handle edge cases.
	MaxBpfUpdateInterval = 60 * time.Second
)

type DnsCache struct {
	RouteOwnerKey    string
	DomainBitmap     []uint32
	Answer           []dnsmessage.RR
	NS               []dnsmessage.RR
	Extra            []dnsmessage.RR
	Deadline         time.Time
	OriginalDeadline time.Time // This field is not impacted by `fixed_domain_ttl`.

	// lastRouteSyncNano tracks when route binding was last synced to BPF.
	lastRouteSyncNano atomic.Int64

	// lastBpfDataHash stores a hash of the data used for BPF update.
	// This enables differential updates - only update when data changes.
	lastBpfDataHash atomic.Uint64

	// packedResponse is a pre-packed DNS response message with compression enabled.
	// This avoids repeated Pack() calls on cache hits, significantly reducing latency.
	// The packed response includes: Answer, Rcode=Success, Response=true, RecursionAvailable=true.
	// Note: DNS Message ID is NOT included and must be patched by the caller.
	//
	// OPTIMIZATION: Uses Copy-on-Write with atomic.Pointer for lock-free reads.
	// This eliminates the performance bottleneck in the hot path (cache hits).
	// Readers never block - they always get a valid (possibly stale) response immediately.
	//
	// Thread-safe access: Use GetPackedResponse() for atomic load.
	// Internal use: ptr := c.packedResponse.Load(); if ptr != nil { data := *ptr }
	packedResponse atomic.Pointer[[]byte]
	// packedResponseTTL is the TTL used when creating packedResponse.
	// Used to determine if refresh is needed (when TTL difference > threshold).
	packedResponseTTL atomic.Uint32
	// packedResponseCreatedAt is the time when packedResponse was created.
	packedResponseCreatedAt atomic.Int64 // UnixNano
	// deadlineNano caches the Deadline as UnixNano for fast comparison.
	// This avoids time.Time method calls on every cache hit.
	deadlineNano atomic.Int64

	// OPTIMISTIC CACHE (RFC 8767): Stale-while-revalidate support
	// refreshing tracks whether background refresh is in progress.
	// This prevents multiple concurrent refresh attempts for the same cache key.
	refreshing atomic.Bool

	// lastAccessNano tracks when this cache was last accessed (for LRU eviction).
	lastAccessNano atomic.Int64
}

func ttlFromDeadline(deadline time.Time, now time.Time) uint32 {
	deadlineNano := deadline.UnixNano()
	nowNano := now.UnixNano()
	if deadlineNano <= nowNano {
		return 0
	}

	ttlSeconds := (deadlineNano - nowNano) / 1e9
	if ttlSeconds < 1 {
		return 1
	}
	return uint32(ttlSeconds)
}

// GetPackedResponse returns the pre-packed DNS response in a thread-safe manner.
// This is a lock-free operation using atomic.Pointer.Load().
// Returns nil if no pre-packed response is available.
//
// OPTIMIZATION: Uses atomic load for zero-contention reads.
// Performance: ~0.2-2ns per call, no memory allocation.
func (c *DnsCache) GetPackedResponse() []byte {
	ptr := c.packedResponse.Load()
	if ptr == nil {
		return nil
	}
	return *ptr
}

func (c *DnsCache) GetFqdn() string {
	if len(c.Answer) > 0 {
		return c.Answer[0].Header().Name
	}
	return ""
}

func (c *DnsCache) MarkRouteBindingRefreshed(now time.Time) {
	c.lastRouteSyncNano.Store(now.UnixNano())
}

// ShouldRefreshRouteBinding checks if route binding needs to be refreshed.
//
// Deprecated: Use NeedsBpfUpdate for differential updates.
func (c *DnsCache) ShouldRefreshRouteBinding(now time.Time, minInterval time.Duration) bool {
	if minInterval <= 0 {
		return true
	}

	nowNano := now.UnixNano()
	last := c.lastRouteSyncNano.Load()
	if last != 0 && nowNano-last < minInterval.Nanoseconds() {
		return false
	}
	return c.lastRouteSyncNano.CompareAndSwap(last, nowNano)
}

// ComputeBpfDataHash computes a hash of the data used for BPF updates.
// This includes IP addresses from Answer and the DomainBitmap.
// Returns 0 if there are no valid IPs (no update needed).
func (c *DnsCache) ComputeBpfDataHash() uint64 {
	if len(c.Answer) == 0 {
		return 0
	}

	var hash uint64 = 14695981039346656037 // FNV-1a offset basis

	// Hash IP addresses from Answer
	for _, ans := range c.Answer {
		var ipBytes []byte
		switch body := ans.(type) {
		case *dnsmessage.A:
			ipBytes = body.A
		case *dnsmessage.AAAA:
			ipBytes = body.AAAA
		}
		if len(ipBytes) > 0 {
			for _, b := range ipBytes {
				hash ^= uint64(b)
				hash *= 1099511628211 // FNV-1a prime
			}
		}
	}

	// Hash DomainBitmap
	for _, v := range c.DomainBitmap {
		hash ^= uint64(v)
		hash *= 1099511628211
	}

	return hash
}

// NeedsBpfUpdate checks if BPF map update is needed using differential detection.
// Returns true if:
//  1. Minimum interval has passed since last update AND
//     (data has changed OR maximum interval has passed)
//  2. Never been updated before
//
// IMPORTANT: This method uses CAS to prevent race conditions. Only one goroutine
// will successfully trigger an update request.
func (c *DnsCache) NeedsBpfUpdate(now time.Time) bool {
	nowNano := now.UnixNano()
	lastSync := c.lastRouteSyncNano.Load()

	// Never updated - needs update (use CAS to claim first update)
	if lastSync == 0 {
		return c.lastRouteSyncNano.CompareAndSwap(0, nowNano)
	}

	timeSinceLastSync := time.Duration(nowNano - lastSync)

	// Haven't reached minimum interval - skip
	if timeSinceLastSync < MinBpfUpdateInterval {
		return false
	}

	// Maximum interval reached - force update (use CAS to claim)
	if timeSinceLastSync >= MaxBpfUpdateInterval {
		return c.lastRouteSyncNano.CompareAndSwap(lastSync, nowNano)
	}

	// Check if data has changed
	currentHash := c.ComputeBpfDataHash()
	if currentHash == 0 {
		// No valid IPs - no update needed
		return false
	}

	lastHash := c.lastBpfDataHash.Load()
	if currentHash == lastHash {
		// Data unchanged - no update needed
		return false
	}

	// Data changed - use CAS to claim this update
	// Only one goroutine will succeed
	return c.lastRouteSyncNano.CompareAndSwap(lastSync, nowNano)
}

// MarkBpfUpdated marks the BPF map as updated with the current data hash.
// This should be called after a successful BPF update.
func (c *DnsCache) MarkBpfUpdated(now time.Time) {
	c.lastRouteSyncNano.Store(now.UnixNano())
	c.lastBpfDataHash.Store(c.ComputeBpfDataHash())
}

func (c *DnsCache) FillInto(req *dnsmessage.Msg) {
	req.Answer = nil
	if c.Answer != nil {
		req.Answer = make([]dnsmessage.RR, len(c.Answer))
		for i, rr := range c.Answer {
			req.Answer[i] = dnsmessage.Copy(rr)
		}
	}
	req.Ns = nil
	if c.NS != nil {
		req.Ns = make([]dnsmessage.RR, len(c.NS))
		for i, rr := range c.NS {
			req.Ns[i] = dnsmessage.Copy(rr)
		}
	}
	req.Extra = nil
	if c.Extra != nil {
		req.Extra = make([]dnsmessage.RR, len(c.Extra))
		for i, rr := range c.Extra {
			req.Extra[i] = dnsmessage.Copy(rr)
		}
	}

	req.Rcode = dnsmessage.RcodeSuccess
	req.Response = true
	req.RecursionAvailable = true
	req.Truncated = false
}

// FillIntoWithPacked fills the DNS response using pre-packed data if available.
// This is the fast path for cache hits - it avoids deep copy and packing overhead.
// Returns the packed response bytes (caller should patch the DNS ID if needed).
func (c *DnsCache) FillIntoWithPacked(req *dnsmessage.Msg) []byte {
	// Fast path: use pre-packed response (lock-free read)
	packedPtr := c.packedResponse.Load()
	if packedPtr != nil && *packedPtr != nil {
		// Still need to unpack to fill the request message for logging/tracing
		// But we return the pre-packed bytes for sending
		return *packedPtr
	}
	// Slow path: fill and pack (should not happen if cache is properly initialized)
	c.FillInto(req)
	req.Compress = true
	b, err := req.Pack()
	if err != nil {
		return nil
	}
	return b
}

func (c *DnsCache) Clone() *DnsCache {
	newCache := &DnsCache{
		RouteOwnerKey:    c.RouteOwnerKey,
		Deadline:         c.Deadline,
		OriginalDeadline: c.OriginalDeadline,
	}

	if c.DomainBitmap != nil {
		newCache.DomainBitmap = slices.Clone(c.DomainBitmap)
	}

	if c.Answer != nil {
		newCache.Answer = make([]dnsmessage.RR, len(c.Answer))
		for i, rr := range c.Answer {
			newCache.Answer[i] = dnsmessage.Copy(rr)
		}
	}
	if c.NS != nil {
		newCache.NS = make([]dnsmessage.RR, len(c.NS))
		for i, rr := range c.NS {
			newCache.NS[i] = dnsmessage.Copy(rr)
		}
	}
	if c.Extra != nil {
		newCache.Extra = make([]dnsmessage.RR, len(c.Extra))
		for i, rr := range c.Extra {
			newCache.Extra[i] = dnsmessage.Copy(rr)
		}
	}

	if packedPtr := c.packedResponse.Load(); packedPtr != nil && *packedPtr != nil {
		packedCopy := slices.Clone(*packedPtr)
		newCache.packedResponse.Store(&packedCopy)
		newCache.packedResponseTTL.Store(c.packedResponseTTL.Load())
		newCache.packedResponseCreatedAt.Store(c.packedResponseCreatedAt.Load())
	}

	newCache.deadlineNano.Store(c.deadlineNano.Load())
	newCache.lastRouteSyncNano.Store(0)
	newCache.lastBpfDataHash.Store(0)

	return newCache

}

// CloneForReload creates a new generation-local cache wrapper for reload.
//
// Immutable payload such as RR slices and the current packed response are reused
// to avoid the reload-time deep-copy spike. Per-generation routing metadata is
// reset so the new control plane can repopulate BPF state with its own routing
// matcher and lifecycle bookkeeping.
func (c *DnsCache) CloneForReload() *DnsCache {
	newCache := &DnsCache{
		RouteOwnerKey:    c.RouteOwnerKey,
		Answer:           c.Answer,
		NS:               c.NS,
		Extra:            c.Extra,
		Deadline:         c.Deadline,
		OriginalDeadline: c.OriginalDeadline,
	}

	if packedPtr := c.packedResponse.Load(); packedPtr != nil && *packedPtr != nil {
		// Packed responses are immutable after publication. Sharing the current
		// bytes avoids a reload-only copy, and each generation still owns its own
		// atomic pointer for future TTL refreshes.
		newCache.packedResponse.Store(packedPtr)
		newCache.packedResponseTTL.Store(c.packedResponseTTL.Load())
		newCache.packedResponseCreatedAt.Store(c.packedResponseCreatedAt.Load())
	}

	deadlineNano := c.deadlineNano.Load()
	if deadlineNano == 0 && !c.Deadline.IsZero() {
		deadlineNano = c.Deadline.UnixNano()
	}
	newCache.deadlineNano.Store(deadlineNano)
	newCache.lastAccessNano.Store(c.lastAccessNano.Load())
	newCache.lastRouteSyncNano.Store(0)
	newCache.lastBpfDataHash.Store(0)
	newCache.refreshing.Store(false)

	return newCache
}

// PrepackResponse generates a pre-packed DNS response message.
// This should be called once when creating the cache entry.
// The qname should be the full qualified domain name (with trailing dot).
// Uses approximate TTL - the pre-packed response is refreshed when TTL changes
// by more than ttlRefreshThresholdSeconds.
func (c *DnsCache) PrepackResponse(qname string, qtype uint16) error {
	now := time.Now()

	// Cache deadline as UnixNano for fast comparison
	c.deadlineNano.Store(c.Deadline.UnixNano())

	return c.prepackResponseWithTTL(qname, qtype, ttlFromDeadline(c.Deadline, now), now)
}

func ttlScratchSlice(n int, stack *[8]uint32) []uint32 {
	if n <= len(stack) {
		return stack[:n]
	}
	return make([]uint32, n)
}

func setSectionTTL(rrs []dnsmessage.RR, ttl uint32, scratch []uint32) {
	for i, rr := range rrs {
		hdr := rr.Header()
		scratch[i] = hdr.Ttl
		hdr.Ttl = ttl
	}
}

func restoreSectionTTL(rrs []dnsmessage.RR, scratch []uint32) {
	for i, rr := range rrs {
		rr.Header().Ttl = scratch[i]
	}
}

// prepackResponseBeforeStore is a lighter pre-pack path used only before the
// cache entry becomes visible to concurrent readers. It temporarily rewrites
// the TTLs in-place, packs the response, and restores the original TTLs before
// returning. This preserves the stored RR values while avoiding deep copies on
// the cold cache-insert path.
func (c *DnsCache) prepackResponseBeforeStore(qname string, qtype uint16, ttl uint32, now time.Time) error {
	var question [1]dnsmessage.Question
	question[0] = dnsmessage.Question{Name: qname, Qtype: qtype, Qclass: dnsmessage.ClassINET}

	msg := dnsmessage.Msg{
		MsgHdr: dnsmessage.MsgHdr{
			Rcode:              dnsmessage.RcodeSuccess,
			Response:           true,
			RecursionAvailable: true,
			RecursionDesired:   true,
			Truncated:          false,
		},
		Question: question[:],
		Answer:   c.Answer,
		Ns:       c.NS,
		Extra:    c.Extra,
		Compress: true,
	}

	var (
		answerStack [8]uint32
		nsStack     [8]uint32
		extraStack  [8]uint32
	)
	answerTTLs := ttlScratchSlice(len(c.Answer), &answerStack)
	nsTTLs := ttlScratchSlice(len(c.NS), &nsStack)
	extraTTLs := ttlScratchSlice(len(c.Extra), &extraStack)

	setSectionTTL(c.Answer, ttl, answerTTLs)
	setSectionTTL(c.NS, ttl, nsTTLs)
	setSectionTTL(c.Extra, ttl, extraTTLs)
	defer func() {
		restoreSectionTTL(c.Extra, extraTTLs)
		restoreSectionTTL(c.NS, nsTTLs)
		restoreSectionTTL(c.Answer, answerTTLs)
	}()

	packed, err := msg.Pack()
	if err != nil {
		return err
	}

	c.packedResponse.Store(&packed)
	c.packedResponseTTL.Store(ttl)
	c.packedResponseCreatedAt.Store(now.UnixNano())
	return nil
}

// prepackResponseWithTTL creates pre-packed response with specified TTL
// OPTIMIZED: Uses Copy-on-Write with atomic pointer swap for thread-safe updates.
// Creates a new []byte slice and atomically swaps the pointer - no blocking readers.
func (c *DnsCache) prepackResponseWithTTL(qname string, qtype uint16, ttl uint32, now time.Time) error {
	msg := &dnsmessage.Msg{
		MsgHdr: dnsmessage.MsgHdr{
			Rcode:              dnsmessage.RcodeSuccess,
			Response:           true,
			RecursionAvailable: true,
			RecursionDesired:   true,
			Truncated:          false,
		},
		Question: []dnsmessage.Question{
			{Name: qname, Qtype: qtype, Qclass: dnsmessage.ClassINET},
		},
		Compress: true,
	}

	if c.Answer != nil {
		msg.Answer = make([]dnsmessage.RR, len(c.Answer))
		for i, rr := range c.Answer {
			copiedRR := dnsmessage.Copy(rr)
			copiedRR.Header().Ttl = ttl
			msg.Answer[i] = copiedRR
		}
	}
	if c.NS != nil {
		msg.Ns = make([]dnsmessage.RR, len(c.NS))
		for i, rr := range c.NS {
			copiedRR := dnsmessage.Copy(rr)
			copiedRR.Header().Ttl = ttl
			msg.Ns[i] = copiedRR
		}
	}
	if c.Extra != nil {
		msg.Extra = make([]dnsmessage.RR, len(c.Extra))
		for i, rr := range c.Extra {
			copiedRR := dnsmessage.Copy(rr)
			copiedRR.Header().Ttl = ttl
			msg.Extra[i] = copiedRR
		}
	}

	packed, err := msg.Pack()
	if err != nil {
		return err
	}

	c.packedResponse.Store(&packed)
	c.packedResponseTTL.Store(ttl)
	c.packedResponseCreatedAt.Store(now.UnixNano())
	return nil
}

// GetPackedResponseWithApproximateTTL returns pre-packed response with approximate TTL.
// OPTIMIZED: Uses Copy-on-Write with atomic.Pointer for lock-free reads.
// Fast path: returns cached pre-packed response if TTL difference is within threshold.
// Slow path: refreshes pre-packed response if TTL has changed significantly.
// THREAD-SAFE: Lock-free reads + atomic updates. No mutex contention.
// PERFORMANCE: Eliminates deep copy + Pack() bottleneck. 10-100x faster for cache hits.
// NOTE: Only returns fresh (unexpired) responses. For stale responses, use GetStaleResponse.
func (c *DnsCache) GetPackedResponseWithApproximateTTL(qname string, qtype uint16, now time.Time) []byte {
	nowNano := now.UnixNano()
	deadlineNano := c.deadlineNano.Load()

	// Check if cache is expired - return nil immediately
	if deadlineNano <= nowNano {
		return nil
	}

	// Calculate current TTL in seconds (avoid float operations)
	currentTTL := uint32((deadlineNano - nowNano) / 1e9)
	if currentTTL == 0 {
		currentTTL = 1
	}

	// Lock-free read: atomic pointer load (no mutex, no blocking)
	packedPtr := c.packedResponse.Load()
	if packedPtr != nil && *packedPtr != nil {
		// Use cached response if TTL difference is within threshold
		cachedTTL := c.packedResponseTTL.Load()
		if cachedTTL >= currentTTL {
			if cachedTTL-currentTTL <= ttlRefreshThresholdSeconds {
				return *packedPtr
			}
		} else if currentTTL-cachedTTL <= ttlRefreshThresholdSeconds {
			return *packedPtr
		}
	}

	// Slow path: refresh pre-packed response with new TTL
	// CAS ensures only one goroutine refreshes per second
	createdNano := c.packedResponseCreatedAt.Load()
	if nowNano-createdNano > 1e9 { // 1 second in nanoseconds
		if c.packedResponseCreatedAt.CompareAndSwap(createdNano, nowNano) {
			// Copy-on-Write: create new response in background, then atomic swap
			// If prepackResponseWithTTL fails, revert timestamp to allow retry
			if err := c.prepackResponseWithTTL(qname, qtype, currentTTL, now); err != nil {
				// Revert timestamp to allow retry sooner (after 100ms instead of 1s)
				c.packedResponseCreatedAt.Store(createdNano)
			}
		}
	}

	// Return current response (might be slightly stale, but acceptable)
	packedPtr = c.packedResponse.Load()
	if packedPtr == nil || *packedPtr == nil {
		return nil
	}
	return *packedPtr
}

// GetStaleResponse returns expired response if within stale-while-revalidate window.
// OPTIMISTIC CACHE (RFC 8767): This is used when cache is expired but still acceptable.
// staleTtl: stale window in seconds. 0 means never expire (always return stale response).
// Returns nil if cache is too stale (beyond staleTtl seconds).
// Caller should check refreshing flag and trigger background refresh if needed.
func (c *DnsCache) GetStaleResponse(now time.Time, staleTtl int) []byte {
	nowNano := now.UnixNano()
	deadlineNano := c.deadlineNano.Load()

	// Cache is not expired - should use GetPackedResponseWithApproximateTTL instead
	if deadlineNano > nowNano {
		return nil
	}

	// Check if within stale-while-revalidate window
	// staleTtl = 0 means never expire (always return stale response)
	if staleTtl > 0 {
		staleNano := deadlineNano + int64(staleTtl)*1e9
		if nowNano > staleNano {
			// Too stale, don't use
			return nil
		}
	}

	// Return stale response (better than nothing)
	packedPtr := c.packedResponse.Load()
	if packedPtr == nil || *packedPtr == nil {
		return nil
	}
	return *packedPtr
}

// IsRefreshing checks if background refresh is in progress (optimistic cache).
// Returns true if this cache entry is expired and currently being refreshed.
func (c *DnsCache) IsRefreshing() bool {
	return c.refreshing.Load()
}

// MarkRefreshed marks the background refresh as complete (optimistic cache).
// This should be called after successfully refreshing the cache.
func (c *DnsCache) MarkRefreshed() {
	c.refreshing.Store(false)
}

// fillIntoWithTTLInPlace mutates req directly and should only be used when the
// caller has unique ownership of req and will not reuse it after the call,
// including on pack failure.
func (c *DnsCache) fillIntoWithTTLInPlace(req *dnsmessage.Msg, now time.Time) []byte {
	if req == nil {
		return nil
	}
	req.Answer = nil
	req.Rcode = dnsmessage.RcodeSuccess
	req.Response = true
	req.RecursionAvailable = true
	req.Truncated = false

	if c.Answer == nil {
		req.Compress = true
		b, _ := req.Pack()
		return b
	}

	// Calculate remaining TTL based on the provided time
	remainingTTL := ttlFromDeadline(c.Deadline, now)

	// Copy answers with updated TTL
	req.Answer = make([]dnsmessage.RR, len(c.Answer))
	for i, rr := range c.Answer {
		copiedRR := dnsmessage.Copy(rr)
		// Update TTL to remaining time
		copiedRR.Header().Ttl = remainingTTL
		req.Answer[i] = copiedRR
	}

	req.Compress = true
	b, err := req.Pack()
	if err != nil {
		return nil
	}
	return b
}

// FillIntoWithTTL fills the DNS response with correct remaining TTL.
// This is the standard DNS cache behavior - TTL decreases over time.
// Returns the packed response bytes ready to send (with DNS ID = 0, caller should patch).
//
// This method preserves the caller's request on failure by operating on a copy.
// Hot paths that already own the message exclusively should use
// fillIntoWithTTLInPlace to avoid the extra allocation.
func (c *DnsCache) FillIntoWithTTL(req *dnsmessage.Msg, now time.Time) []byte {
	if req == nil {
		return nil
	}
	resp := req.Copy()
	if resp == nil {
		return nil
	}
	return c.fillIntoWithTTLInPlace(resp, now)
}

func (c *DnsCache) IncludeIp(ip netip.Addr) bool {
	for _, ans := range c.Answer {
		if a, ok := dnsAnswerIP(ans); ok && a == ip {
			return true
		}
	}
	return false
}

func (c *DnsCache) IncludeAnyIp() bool {
	for _, ans := range c.Answer {
		switch ans.(type) {
		case *dnsmessage.A, *dnsmessage.AAAA:
			return true
		}
	}
	return false
}

func dnsAnswerIP(rr dnsmessage.RR) (netip.Addr, bool) {
	switch body := rr.(type) {
	case *dnsmessage.A:
		return netip.AddrFromSlice(body.A)
	case *dnsmessage.AAAA:
		return netip.AddrFromSlice(body.AAAA)
	default:
		return netip.Addr{}, false
	}
}
